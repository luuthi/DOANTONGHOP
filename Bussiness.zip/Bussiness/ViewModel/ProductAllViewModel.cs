﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness.ViewModel
{
    public class ProductAllViewModel
    {
        public List<List<ProductViewModel>> lstListProduct { get; set; }
    }
}
